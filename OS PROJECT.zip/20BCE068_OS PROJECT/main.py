def prRed(skk): 
    print("\033[91m{}\033[00m" .format(skk))

def Avg_TAT_WT(gant,l):
    gant = gant[::-1]
    g=[]
    h=[]
    
    for i in range(len(gant)):
        if gant[i] not in g:
            g.append(gant[i])
            h.append(len(gant)-i)
    
    s=[]
    for i in range(len(g)):
        s.append([g[i],h[i]])
    s = sorted(s,key = lambda process: process[0])
    
    tt=[]
    ttsum=0
    for i in range(len(s)):
        tt.append(s[i][1]-l[i][1])
        ttsum+=s[i][1]-l[i][1]
    prRed("Average TurnAround time is "+str(ttsum/len(l))+" ms")
    
    wt =[]
    wtsum=0
    for i in range(len(s)):
        wt.append(tt[i]-l[i][2])
        wtsum+=tt[i]-l[i][2]
    prRed("Average Waiting time is "+str(wtsum/len(l))+" ms")

def Avg_res(gant,l):
    g=[]
    h=[]
    for i in range(len(gant)):
        if gant[i] not in g:
            g.append(gant[i])
            h.append(i)
    sum=0
    for i in  range(len(l)):
        sum+=(h[i]-l[i][1])
    prRed("Avgerage Responce time is "+str(sum/len(l))+" ms")
    
def tp(l):
    sum = 0
    for i in range(len(l)):
        sum+= l[i][2]
    prRed("Overall throughput: "+str(len(l)/sum))
    
def fcfs(l):
    gantt = ""
    sort_list = sorted(l,key = lambda process: process[1])  #Sorted by Arrival time
    for i in sort_list:
        gantt += str(i[0])*i[2]
    print(gantt)
    Avg_res(gantt,l)
    Avg_TAT_WT(gantt,l)   


def sjf(l):
    gantt= ""
    t = 0
    p = []
    for i in range(len(l)):
        s = []
        for j in range(len(l)):
            if l[j][1] <= t:
                if l[j][0] not in p:
                    s.append(l[j])
        s = sorted(s,key = lambda process: process[2])
        gantt+=str(s[0][0])*s[0][2]
        p.append(s[0][0])
        t+=s[0][2]
    print(gantt)
    Avg_res(gantt,l)
    Avg_TAT_WT(gantt,l)
    
def srtf(l):
    gantt= ""
    total=0                         #for total time for all process to be finished
    for i in range(len(l)):
        total+=l[i][2]
    count=0
    d={"":1000}
    while count<=total:
        for i in l:
            if i[1] == count:       #arrival-time == current-time
                d[i[0]] = i[2]      #added to dictonary key as process number & Burst-time as value
        y=min(d, key=d.get)         #min by Burst-time
        gantt+=str(y)
        d[y]=d[y]-1                 #updating burst-time as reamining time
        if d[y]==0:
            d.pop(y)                #if process is finished then it will be popped
        count+=1
    print(gantt)
    Avg_res(gantt,l)
    Avg_TAT_WT(gantt,l)

def rr(l,qt,org):
    gantt= ""
    d = {}
    x = 0
    count = 0
    sum1 = max(l,key = lambda parameter: parameter[1])[1]
    p = []
    for i in l:
        d[i[0]] = i[1]
    for i in range(len(l)):
        if l[i][2]%qt == 0:
            x += int(l[i][2]/qt)
        else:
            x += int(l[i][2]/qt) + 1
            
    for i in range(x):
        s = []
        for j in range(len(l)):
            if l[j][1] <= count:
                if l[j] not in p and l[j][0] != -1:
                    p.append(l[j])
        for k in range(len(p)):
            s.append([p[k][0],count-d[p[k][0]]])
        s = sorted(s,key = lambda item: item[1],reverse = True)
        y = s[0][0]
        if l[y-1][2] >= qt:
            gantt+=str(y)*qt
            count += qt
            l[y-1][2] -= qt
        else:
            gantt+=str(y)*l[y-1][2]
            count += l[y-1][2]
            l[y-1][2] -= l[y-1][2]
        d[y] = count
        if l[y-1][2] == 0:
            p.remove(l[y-1])
            l[y-1]=[-1,-1,-1]
    print(gantt)
    Avg_res(gantt,org)
    Avg_TAT_WT(gantt,l)

#main function 
if __name__ == "__main__":
    os = open("input.txt","r")
    info = []   #list that will carry Information of Every process
    l = os.readlines()
    
    count = 0
    for i in l:
        if count==0:     #for skipping First line(headings) of input.txt 
            count+=1
            continue
        else:
            info.append(i.split(" "))
     # for converting Info list -> tuple, so it cant be changed by any function 
    temp = []
    for i in range(len(info)): 
        map_object = map(int, info[i])
        new_info = list(map_object)
        temp.append(tuple(new_info))
    info = tuple(temp)
    
    while True:     # Switch-case
        
        li  = []
        for i in info:
            li.append(list(i))
            
        print("\n\n*******************************")
        print("1.First come First serves")
        print("2.Shortest Job First")
        print("3.Shortest Remainnig Time First")
        print("4.Round Robin")
        print("5.Exit")
        print("*******************************")
        ch = int(input("Enter your choice: "))
        if ch == 1:
            prRed("\n\nGANTT CHART: ")
            fcfs(li)
            tp(info)
        elif ch == 2:
            prRed("\n\nGANTT CHART: ")
            sjf(li)
            tp(info)
        elif ch == 3:
            prRed("\n\nGANTT CHART: ")
            srtf(li)
            tp(info)
        elif ch == 4:
            Q = int(input("Enter the qauntam time (in ms) : "))
            prRed("\n\nGANTT CHART: ")
            rr(li,Q,info)
            tp(info)
    
        elif ch == 5:
            print("Exited\n")
            break
        else:
            print("wrong choice\n")