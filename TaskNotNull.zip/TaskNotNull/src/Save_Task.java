import java.io.IOException;
import java.io.RandomAccessFile;


 /**
 * The class Save_ task
 */
public class Save_Task {
    public String name;

    Save_Task(String name) {
        this.name = name;
    }


/**
 *
 * Savetask
 *
 * @param task  the task
 */
    public void savetask(String task) {

        try {
            String file_name = name + ".txt";
            RandomAccessFile file = new RandomAccessFile(file_name,"rw"); // r for read and rw for read and write.
            file.seek(file.length());
            //task=task+"\n";
            file.writeBytes(task+"\n");
            file.close();
        } catch (IOException e) {
            System.out.println("Details not saved");
            e.printStackTrace();
        }
    }
}


