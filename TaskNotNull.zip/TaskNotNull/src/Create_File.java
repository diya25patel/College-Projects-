import java.io.File;
        import java.io.IOException;


 /**
 * The class Create_ file
 */
public class Create_File {
    public String name;

    Create_File(String name) {
        this.name = name;
    }


/**
 *
 * Create file
 *
 * @return int
 */
    public int createFile() {


        // 0 - Error in file creation
        // 1 - New file created
        // 2 - File already exists

        try {
            String file_name = name + ".txt";
            File file = new File(file_name);
            if (file.createNewFile()) {
                return 1;
            } else {
                return 2;
            }
        } catch (IOException exception) {
            System.out.println("Unexpected error");
            exception.printStackTrace();
            return 0;
        }
    }
}
