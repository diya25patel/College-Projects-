port java.io.*;
import java.nio.file.Files;
import java.util.Scanner;


 /**
 * The class Delete_ task
 */
public class Delete_Task {
    String filename;
    int lineNo;
    String requiredLine;
    Delete_Task(String filename,int lineNo)
    {
        this.filename=filename;
        this.lineNo=lineNo;
    }


/**
 *
 * Delete task
 *
 */
    public void deleteTask()
    {

        try {
            String file_name = filename + ".txt";
            File file = new File(file_name);
            Scanner scan = new Scanner(file);
            int n=1;
            while (scan.hasNextLine()) {
                String task = scan.nextLine();
                if(n==lineNo)
                {
                   requiredLine = task;
                   break;
                }
                n++;
            }
            scan.close();
        } catch (FileNotFoundException exception) {
            System.out.println("--> No such User found");
            exception.printStackTrace();
        }
        removeLine(requiredLine);

    }

/**
 *
 * Remove line
 *
 * @param lineContent  the line content
 */
    public void removeLine(String lineContent)  {

        File file = new File(filename+".txt");
        File temp = new File("temp.txt");
        PrintWriter out = null;
        try {
            out = new PrintWriter(new FileWriter(temp));
            Files.lines(file.toPath())
                    .filter(line -> !line.contains(lineContent))
                    .forEach(out::println);
            out.flush();
            out.close();
            Delete_File df = new Delete_File(filename);
            df.deleteFile();
            temp.renameTo(file);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
