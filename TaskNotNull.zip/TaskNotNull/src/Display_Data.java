import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Display_Data {
    public String name;
    Display_Data(String name)
    {
        this.name = name+".txt";
    }
    public void displayData()
    {
        try {
            String file_name = name;
            File file = new File(file_name);
            Scanner scan = new Scanner(file);
            int n=1;
            if(!scan.hasNextLine())
            {
                System.out.println("--> No User Added");
                return;
            }
            System.out.println("Displaying the user details");
            while (scan.hasNextLine()) {
                String userData = scan.nextLine();
                int idx = userData.indexOf("#");
                userData = userData.substring(0,idx);
                System.out.println(n+") "+userData);
                n++;
            }
            scan.close();
        } catch (FileNotFoundException exception) {
            System.out.println("No Users found");
            exception.printStackTrace();
        }
    }
}
