import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
* The class Check_ login
*/
public class Check_Login {
    public String name;
    Check_Login(String name) {
        this.name = name;
    }
/**
 *
 * Read file
 *
 * @param entered_login  the entered_login
 * @param entered_pass  the entered_pass
 * @return int
 */
    public int readFile(String entered_login, String entered_pass) {

        // 0 - error
        // 1 - correct credentials
        // 2 - wrong credentials

        try {
            String file_name = name + ".txt";
            File file = new File(file_name);
            Scanner scan = new Scanner(file);

            int flag = 0;
            while (scan.hasNextLine()) {
                String fileData = scan.nextLine();
                String[] saved_details = fileData.split("#");
                /*System.out.println(fileData);
                System.out.println(saved_details[0]);
                System.out.println(saved_details[1]);
                int lastidx = fileData.lastIndexOf("#");
                int idx =fileData.indexOf("#");
                saved_details[1]=fileData.substring(idx+1,lastidx);*/
                if (saved_details[0].equals(entered_login)&& saved_details[1].equals(entered_pass)) {
                    flag = 1;
                    break;
                }
            }
            scan.close();

            if (flag == 0)
                return 2;
            else
                return 1;
        } catch (FileNotFoundException exception) {
            exception.printStackTrace();
            return 0;
        }
    }
}
