// Importing the File class
import java.io.File;
// Importing FileNotFoundException class for handling errors
import java.io.FileNotFoundException;
// Importing the Scanner class for reading text files
import java.util.Scanner;


 /**
 * The class Read_ admin_ file
 */
public class Read_Admin_File {
    public String name;
    Read_Admin_File(String name)
    {
        this.name=name+".txt";
    }

/**
 *
 * Read
 *
 * @return String
 */
    public String read() {

        try {
            // Create f1 object of the file to read data
            File f1 = new File(name);
            Scanner scan = new Scanner(f1);
            String fileData = scan.nextLine();
            scan.close();
            return fileData;
        } catch (FileNotFoundException exception) {
            System.out.println("Unexpected error occurred!");
            exception.printStackTrace();
        }
        return "Hello";
    }
}
