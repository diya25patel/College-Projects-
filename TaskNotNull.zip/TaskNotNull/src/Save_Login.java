import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


 /**
 * The class Read_ user_ tasks
 */
public class Read_User_Tasks {
    public String name;
    public String id;
    Read_User_Tasks(String name) {
        this.name = name;
    }


/**
 *
 * Read file
 *
 * @param entered_login  the entered_login
 * @return int
 */
    public int readFile(String entered_login) {




        // 0 - error
        // 1 - correct credentials
        // 2 - wrong credentials

        try {
            String file_name = name + ".txt";
            File file = new File(file_name);
            Scanner scan = new Scanner(file);

            int flag = 0;
            while (scan.hasNextLine()) {
                String fileData = scan.nextLine();
                String[] saved_details = fileData.split("#");
                if (saved_details[0].equals(entered_login)) {
                    id=saved_details[0];
                    flag = 1;
                    break;
                }
            }
            scan.close();

            if (flag == 0) {
                System.out.println("--> Error 404 ::  No Such User Found");
                return 0;
            }

            else {
                Read_Task readtask = new Read_Task(id);
                int n = readtask.readTask();
                return n;
            }

        } catch (FileNotFoundException exception) {
            exception.printStackTrace();
        }
        return 0;
    }
}

