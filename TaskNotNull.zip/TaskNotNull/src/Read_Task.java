import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


 /**
 * The class Read_ task
 */
public class Read_Task {
    public String name;

    Read_Task(String name) {
        this.name = name;
    }


/**
 *
 * Read task
 *
 * @return int
 */
    public int readTask() {

        try {
            String file_name = name + ".txt";
            File file = new File(file_name);
            Scanner scan = new Scanner(file);
            int n=1;
            if(!scan.hasNextLine())
            {
                System.out.println("--> No Tasks added");
                return -1;
            }
            while (scan.hasNextLine()) {
                String task = scan.nextLine();
                System.out.println(n+") "+task);
                n++;
            }
            scan.close();
            return n-1;
        } catch (FileNotFoundException exception) {
            System.out.println("--> No such User found");
            exception.printStackTrace();
        }
        return 0;
    }
}

