import java.io.File;


 /**
 * The class Delete_ file
 */
public class Delete_File {

    public String name;

    Delete_File(String name) {
        this.name = name;
    }


/**
 *
 * Delete file
 *
 * @return int
 */
    public int deleteFile() {


        // 1 - file deleted
        // 2 - error
        String file_name = name + ".txt";
        File file = new File(file_name);
        if (file.delete()) {
            return 1;
        } else {
            return 2;
        }
    }
}
