import java.io.FileWriter;
import java.io.IOException;


 /**
 * The class Write_ admin_ file
 */
public class Write_Admin_File {
    public String name;

    Write_Admin_File(String name) {
        this.name = name;
    }


/**
 *
 * Sets the admin
 *
 * @param id  the id
 * @param password  the password
 */
    public void setAdmin(String id,String password) {

        try {
            String file_name = name + ".txt";
            FileWriter fwrite = new FileWriter(file_name);
            fwrite.append(id).append("#").append(password);
            fwrite.close();
            //System.out.println("Content is successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("Unexpected error occurred");
            e.printStackTrace();
        }
    }
}
