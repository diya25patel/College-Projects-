import java.util.*;

class admin
{
     private String id;
     private String password;
     admin()
     {
         System.out.println("Error 101 : Wrong Use of Code");
     }
     admin(String id,String password)
     {
         this.id=id;
         this.password=password;
     }

/**
 *
 * Gets the identifier
 *
 * @return the identifier
 */
    public String getId() {

        return id;
    }


/**
 *
 * Gets the password
 *
 * @return the password
 */
    public String getPassword() {

        return password;
    }


/**
 *
 * Sets the identifier
 *
 * @param id  the id
 */
    public void setId(String id) {

        this.id = id;
    }


/**
 *
 * Sets the password
 *
 * @param password  the password
 */
    public void setPassword(String password) {

        this.password = password;
    }
}
class user extends admin{
    /*private String task;

/**
 *
 * Sets the task
 *
 * @param task  the task
 */
    public void setTask(String task) {

        this.task = task;
    }*/
}
public class Home {
    static Scanner scan = new Scanner(System.in);
    static void tempDisplay(){
        String id,pass;
        System.out.println("Welcome dear user, set the admin details");
        System.out.println("-----------------------------------------------------");
        System.out.print("Enter the admin id (format : ) : ");
        id = scan.next();
        System.out.print("Enter the password (format : ) : ");
        pass = scan.next();
         Write_Admin_File file = new Write_Admin_File("adminFile");
        file.setAdmin(id,pass);
       // System.out.print("\033[H\033[2J");
       // System.out.flush();
    }
    static void option()
    {
        System.out.println("Select from below option");
        System.out.println("1) Admin Login");
        System.out.println("2) User Login");
        System.out.println("3) Exit");
        System.out.print("--> ");
    }
    static void addUser()
    {
        System.out.println("-----------------------------------------------------");
        String id,pass;
        System.out.println("Enter the new user details");
        System.out.print("Enter the id : ");
        id=scan.next();
        System.out.print("Enter the password : ");
        pass=scan.next();
        Create_File createUserFile = new Create_File("userFile");
        int n = createUserFile.createFile();
        Save_Login adduserLogin = new Save_Login("userFile");
        adduserLogin.saveLogin(id,pass);
        Create_File createFile = new Create_File(id);
        n = createFile.createFile();

    }
    static void deleteUser()
    {
        System.out.println("-----------------------------------------------------");
        String tempid,temppass;
        System.out.print("Enter User Id : ");
        tempid= scan.next();
        System.out.print("Enter Password : ");
        temppass=scan.next();
        Delete_File deleteuser = new Delete_File(tempid);
        int n = deleteuser.deleteFile();
        if(n==1)
        {
            Reset_Password delUser = new Reset_Password("userFile");
            delUser.removeLine(tempid+"#"+temppass);
        }
        else
        {
            System.out.println("No Such User Exists");
        }
    }
    static void visitUser()
    {
        String id;
        System.out.print("Enter the user id : ");
        id=scan.next();
        Read_User_Tasks readUser = new Read_User_Tasks("userFile");
        readUser.readFile(id);
    }
    static void adminMenu(){
        loop : while (true)
        {
            System.out.println("\n-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-");
            int opt;
            System.out.println("Select from below option");
            System.out.println("1) Add User");
            System.out.println("2) Delete User");
            System.out.println("3) Display Users");
            System.out.println("4) Visit User Tasks");
            System.out.println("5) Reset Password");
            System.out.println("6) Logout");
            System.out.print("--> ");
            opt=scan.nextInt();
            switch (opt)
            {
                case 1:
                    addUser();
                    break;
                case 2:
                    deleteUser();
                    break;
                case 3:
                    displayUsers();
                    break;
                case 4:
                    visitUser();
                    break;
                case 5:
                    resetAdmin();
                    break ;
                case 6:
                    break loop;
                default :
                    System.out.println("--> Error 202 : Invalid Selection");
                    break;
            }
        }
    }
    static void displayUsers()
    {
        System.out.println("-----------------------------------------------------");
        Display_Data displayUser = new Display_Data("userFile");
        displayUser.displayData();
        System.out.println("-----------------------------------------------------");
    }
    static int displayTask(String id)
    {
        Read_Task rtask = new Read_Task(id);
        int n = rtask.readTask();
        return n;
    }
    static  void addTask(String id){
        String task;
        System.out.println("Enter the task");
        System.out.print("--> ");
        task=scan.next();
        Save_Task stask = new Save_Task(id);
        stask.savetask(task);
    }
    static void deleteTask(String id){
          int n = displayTask(id);
          if(n>0)
          {
              int num;
              System.out.print("Enter the task number to be deleted : ");
              num=scan.nextInt();
              if(num>n||num<=0)
              {
                  System.out.println("--> Error 202 : Invalid Selection");
              }
              else
              {
                  Delete_Task dtask = new Delete_Task(id,num);
                  dtask.deleteTask();
              }
          }
    }
    static void resetUser()  {
        Reset_Password rset = new Reset_Password("userFile");
        rset.resetPass();
    }
    static void resetAdmin()  {
        Reset_Password rset = new Reset_Password("adminFile");
        rset.resetPass();
    }
    static void userMenu(String id)
    {
        loop : while (true)
        {
            System.out.println("\n-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-");
            int opt;
        System.out.println("Select from below option");
        System.out.println("1) Add Task");
        System.out.println("2) Delete Task");
        System.out.println("3) Display Task");
        System.out.println("4) Reset Password");
        System.out.println("5) Logout");
        System.out.print("--> ");
            opt=scan.nextInt();
            switch (opt)
            {
                case 1:
                    addTask(id);
                    break;
                case 2:
                    deleteTask(id);
                    break;
                case 3:
                   int n = displayTask(id);
                    break;
                case 4:
                    resetUser();
                    break;
                case 5:
                    break loop;
                default :
                    System.out.println("--> Error 202 : Invalid Selection");
                    break;
            }
        }
    }
    static void checkAdmin(String id,String pass)
    {
        System.out.println("-----------------------------------------------------");
        String tempid,temppass;
        System.out.print("Enter Admin Id : ");
        tempid= scan.next();
        System.out.print("Enter Password : ");
        temppass=scan.next();
        if(tempid.equals(id)&&temppass.equals(pass))
        {
            //System.out.println("Successfully Coded");
            adminMenu();
        }
        else
        {
            System.out.println("-------------------------");
            System.out.println("--> Wrong Credentials ");
            System.out.println("-------------------------");
        }
    }
    static void checkUser()
    {
        System.out.println("-----------------------------------------------------");
        String tempid,temppass;
        System.out.print("Enter User Id : ");
        tempid= scan.next();
        System.out.print("Enter Password : ");
        temppass=scan.next();
        Check_Login checkUser = new Check_Login("userFile");
        int n = checkUser.readFile(tempid,temppass);
        if(n==1)
        {
            userMenu(tempid);
        }
        else
        {
            System.out.println("-------------------------");
            System.out.println("--> Wrong Credentials ");
            System.out.println("-------------------------");
        }
    }

/**
 *
 * Main
 *
 * @param args  the args
 */
    public static void main(String[] args) {

        System.out.println("-*-*-*-*-*-*-*-*-*-*-*-* TaskNotNULL *-*-*-*-*-*-*-*-*-*-*-*-");
        Create_File adminFile = new Create_File("adminFile");
        int check = adminFile.createFile();
        if(check==1)
        {
            tempDisplay();
          //  System.out.println("-*-*-*-*-*-*-*-*-*-*-*-* TaskNotNULL *-*-*-*-*-*-*-*-*-*-*-*-");
        }
        Read_Admin_File readAdmin = new Read_Admin_File("adminFile");
        String AdIDPASS = readAdmin.read();
        int idx = AdIDPASS.indexOf("#");
        String loopId=AdIDPASS.substring(0,idx),loopPass=AdIDPASS.substring(idx+1);
      //  System.out.println(loopId+" "+loopPass);
        admin Admin = new admin(loopId,loopPass);
        loop : while(true)
        {
            System.out.println("\n-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-");
            int opt;
            option();
            opt = scan.nextInt();
            switch(opt)
            {
                case 1:
                    checkAdmin(Admin.getId(),Admin.getPassword());
                    break;
                case 2:
                    checkUser();
                    break;
                case 3:
                    break loop;
                default:
                    System.out.println("Error 202 : Invalid Selection");
                    break;
            }
        }
        System.out.println("------------------END------------------");
    }
}

/*
The Assignment is done by:
20BCE016- ARUNIMA BARIK
20BCE068- DIYA PATEL
20BCE079- GAURAV GOLCHHA
**
/
